# YOLO Travel Planning Application

이 프로젝트는 GitHub Pages에서 호스팅되는 정적 버전의 YOLO 여행 계획 웹사이트입니다.

## 특징

- 🏖️ **여행 스타일 선택**: 힐링, 맛집, 모험, 문화, 자연, 쇼핑
- 💰 **예산 계산기**: 실시간 예산 관리 및 시각화
- ⭐ **여행 후기**: 사용자 리뷰 및 평점 시스템
- 🤔 **FAQ/고객센터**: 자주 묻는 질문 및 문의하기
- 🔐 **회원 시스템**: 로그인/회원가입 (로컬 저장소 기반)

## 체험 계정

- 아이디: demo
- 비밀번호: demo123

## 로컬 실행

```bash
npm install
npm run dev
```

## 빌드

```bash
npm run build
```

## 기술 스택

- React + TypeScript
- Tailwind CSS + shadcn/ui
- Vite
- LocalStorage (데이터 저장)

## 배포

이 프로젝트는 GitHub Pages에서 정적 사이트로 호스팅됩니다.
