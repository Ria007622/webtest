// Static version of queryClient that doesn't rely on server API
import { staticStorage } from './staticData';

export class StaticQueryClient {
  private cache = new Map<string, any>();

  async query(queryKey: string[]) {
    const key = queryKey.join(':');
    
    if (this.cache.has(key)) {
      return this.cache.get(key);
    }

    let data;
    
    switch (queryKey[0]) {
      case '/api/reviews':
        data = staticStorage.getReviews();
        break;
      case '/api/faqs':
        data = staticStorage.getFAQs();
        break;
      case '/api/trips':
        if (queryKey[1]) {
          data = staticStorage.getTripsByUser(parseInt(queryKey[1]));
        } else {
          data = staticStorage.getTrips();
        }
        break;
      case '/api/budgets':
        if (queryKey[1]) {
          data = staticStorage.getBudgetByTrip(parseInt(queryKey[1]));
        } else {
          data = staticStorage.getBudgets();
        }
        break;
      default:
        data = null;
    }

    this.cache.set(key, data);
    return data;
  }

  async mutate(url: string, options: any) {
    const { method, body } = options;
    const data = body ? JSON.parse(body) : {};

    switch (url) {
      case '/api/trips':
        if (method === 'POST') {
          return staticStorage.createTrip(data);
        }
        break;
      case '/api/budgets':
        if (method === 'POST') {
          return staticStorage.createBudget(data);
        }
        break;
      case '/api/reviews':
        if (method === 'POST') {
          return staticStorage.createReview(data);
        }
        break;
      case '/api/inquiries':
        if (method === 'POST') {
          return staticStorage.createInquiry(data);
        }
        break;
    }

    // Clear relevant cache
    this.invalidateQueries(url);
    return data;
  }

  invalidateQueries(pattern: string) {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

export const staticQueryClient = new StaticQueryClient();