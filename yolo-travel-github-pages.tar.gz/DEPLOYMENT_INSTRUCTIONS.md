# GitHub Pages 배포 안내

## 1. 빌드된 파일 확인
- `github-pages-build` 폴더에 GitHub Pages용 파일들이 준비되었습니다.

## 2. GitHub 저장소 설정
1. 이 폴더의 내용을 GitHub 저장소에 업로드하세요
2. Repository Settings > Pages로 이동
3. Source를 "GitHub Actions"로 설정

## 3. 배포 주소
배포가 완료되면 다음 주소에서 사이트를 확인할 수 있습니다:
https://ria007622.github.io/webtest/Home/

## 4. 체험 계정
- 아이디: demo
- 비밀번호: demo123

## 주의사항
- 모든 데이터는 브라우저의 로컬 저장소에 저장됩니다
- 브라우저 데이터를 지우면 저장된 정보가 삭제됩니다
- 정적 사이트이므로 서버 기능은 클라이언트에서 시뮬레이션됩니다
