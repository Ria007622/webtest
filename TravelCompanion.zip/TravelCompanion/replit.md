# YOLO Travel Platform

## Overview

YOLO is a comprehensive travel platform built as a full-stack web application designed to help users discover, plan, and book travel experiences. The application provides a seamless interface for browsing destinations, booking hotels and activities, sharing reviews, and managing travel plans.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom design tokens
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Authentication**: Replit Authentication with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL storage
- **API Design**: RESTful endpoints with proper error handling

### Database Layer
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with type-safe queries
- **Schema Management**: Drizzle Kit for migrations and schema changes
- **Connection**: Connection pooling via @neondatabase/serverless

## Key Components

### Authentication System
- Replit Auth integration with OIDC
- Session-based authentication with PostgreSQL session store
- User profile management with avatar and basic info
- Protected routes with middleware authentication checks

### Core Entities
- **Users**: Profile management and authentication
- **Destinations**: Travel locations with ratings and descriptions
- **Hotels**: Accommodation options with amenities and pricing
- **Activities**: Local experiences and tours
- **Bookings**: Reservation management system
- **Reviews**: User-generated content and ratings
- **Travel Plans**: Personal itinerary management

### UI Component System
- Comprehensive component library based on Radix UI
- Consistent design system with CSS custom properties
- Responsive design with mobile-first approach
- Accessible components following ARIA guidelines
- Korean language support with appropriate fonts

## Data Flow

### Client-Server Communication
- RESTful API endpoints for all data operations
- TanStack Query for caching and synchronization
- Error handling with user-friendly messages
- Loading states and optimistic updates

### Authentication Flow
1. User initiates login via Replit Auth
2. OIDC flow redirects to authentication provider
3. Successful authentication creates/updates user session
4. Session stored in PostgreSQL with automatic cleanup
5. Client receives user data and authentication state

### Data Management
- Drizzle ORM provides type-safe database operations
- Shared schema definitions between client and server
- Zod validation for data integrity
- Proper error handling and rollback mechanisms

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **connect-pg-simple**: PostgreSQL session store for Express
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight React router
- **@radix-ui/***: Accessible UI primitives

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast bundling for production builds
- **tailwindcss**: Utility-first CSS framework
- **vite**: Build tool and development server

### Authentication
- **openid-client**: OIDC implementation
- **passport**: Authentication middleware
- **express-session**: Session management

## Deployment Strategy

### Development Environment
- Replit-hosted development with live reload
- Vite development server with HMR
- PostgreSQL database provisioning
- Environment variable management

### Production Build
- Vite builds optimized client bundle
- ESBuild compiles server code
- Static assets served from Express
- Single deployment target with autoscaling

### Environment Configuration
- **Development**: `npm run dev` - runs server with TSX
- **Production**: `npm run build && npm run start`
- **Database**: `npm run db:push` for schema updates

### Hosting Requirements
- Node.js 20+ runtime
- PostgreSQL database
- Environment variables for authentication and database connection
- Static file serving capability

## Changelog

Changelog:
- June 27, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.