import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertBookingSchema, insertReviewSchema, insertTravelPlanSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Destination routes
  app.get("/api/destinations", async (req, res) => {
    try {
      const destinations = await storage.getDestinations();
      res.json(destinations);
    } catch (error) {
      console.error("Error fetching destinations:", error);
      res.status(500).json({ message: "Failed to fetch destinations" });
    }
  });

  app.get("/api/destinations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const destination = await storage.getDestination(id);
      if (!destination) {
        return res.status(404).json({ message: "Destination not found" });
      }
      res.json(destination);
    } catch (error) {
      console.error("Error fetching destination:", error);
      res.status(500).json({ message: "Failed to fetch destination" });
    }
  });

  app.get("/api/destinations/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const destinations = await storage.searchDestinations(query);
      res.json(destinations);
    } catch (error) {
      console.error("Error searching destinations:", error);
      res.status(500).json({ message: "Failed to search destinations" });
    }
  });

  // Hotel routes
  app.get("/api/hotels", async (req, res) => {
    try {
      const destinationId = req.query.destinationId 
        ? parseInt(req.query.destinationId as string) 
        : undefined;
      const hotels = await storage.getHotels(destinationId);
      res.json(hotels);
    } catch (error) {
      console.error("Error fetching hotels:", error);
      res.status(500).json({ message: "Failed to fetch hotels" });
    }
  });

  app.get("/api/hotels/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const hotel = await storage.getHotel(id);
      if (!hotel) {
        return res.status(404).json({ message: "Hotel not found" });
      }
      res.json(hotel);
    } catch (error) {
      console.error("Error fetching hotel:", error);
      res.status(500).json({ message: "Failed to fetch hotel" });
    }
  });

  app.get("/api/hotels/search", async (req, res) => {
    try {
      const params = {
        destination: req.query.destination as string,
        checkIn: req.query.checkIn as string,
        checkOut: req.query.checkOut as string,
        guests: req.query.guests ? parseInt(req.query.guests as string) : undefined,
        minPrice: req.query.minPrice ? parseInt(req.query.minPrice as string) : undefined,
        maxPrice: req.query.maxPrice ? parseInt(req.query.maxPrice as string) : undefined,
      };
      const hotels = await storage.searchHotels(params);
      res.json(hotels);
    } catch (error) {
      console.error("Error searching hotels:", error);
      res.status(500).json({ message: "Failed to search hotels" });
    }
  });

  // Activity routes
  app.get("/api/activities", async (req, res) => {
    try {
      const destinationId = req.query.destinationId 
        ? parseInt(req.query.destinationId as string) 
        : undefined;
      const activities = await storage.getActivities(destinationId);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  app.get("/api/activities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      res.json(activity);
    } catch (error) {
      console.error("Error fetching activity:", error);
      res.status(500).json({ message: "Failed to fetch activity" });
    }
  });

  app.get("/api/activities/search", async (req, res) => {
    try {
      const params = {
        destination: req.query.destination as string,
        category: req.query.category as string,
        minPrice: req.query.minPrice ? parseInt(req.query.minPrice as string) : undefined,
        maxPrice: req.query.maxPrice ? parseInt(req.query.maxPrice as string) : undefined,
      };
      const activities = await storage.searchActivities(params);
      res.json(activities);
    } catch (error) {
      console.error("Error searching activities:", error);
      res.status(500).json({ message: "Failed to search activities" });
    }
  });

  // Booking routes (protected)
  app.get("/api/bookings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookings = await storage.getUserBookings(userId);
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.post("/api/bookings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookingData = insertBookingSchema.parse({
        ...req.body,
        userId,
      });
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.patch("/api/bookings/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const booking = await storage.updateBookingStatus(id, status);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      res.json(booking);
    } catch (error) {
      console.error("Error updating booking status:", error);
      res.status(500).json({ message: "Failed to update booking status" });
    }
  });

  // Review routes
  app.get("/api/reviews", async (req, res) => {
    try {
      const type = req.query.type as string;
      const itemId = parseInt(req.query.itemId as string);
      
      if (!type || !itemId) {
        return res.status(400).json({ message: "Type and itemId are required" });
      }
      
      const reviews = await storage.getReviews(type, itemId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get("/api/reviews/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviews = await storage.getUserReviews(userId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching user reviews:", error);
      res.status(500).json({ message: "Failed to fetch user reviews" });
    }
  });

  app.post("/api/reviews", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        userId,
      });
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Travel plan routes (protected)
  app.get("/api/travel-plans", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const plans = await storage.getUserTravelPlans(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching travel plans:", error);
      res.status(500).json({ message: "Failed to fetch travel plans" });
    }
  });

  app.post("/api/travel-plans", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const planData = insertTravelPlanSchema.parse({
        ...req.body,
        userId,
      });
      const plan = await storage.createTravelPlan(planData);
      res.status(201).json(plan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid travel plan data", errors: error.errors });
      }
      console.error("Error creating travel plan:", error);
      res.status(500).json({ message: "Failed to create travel plan" });
    }
  });

  app.put("/api/travel-plans/:id", isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const plan = await storage.updateTravelPlan(id, updates);
      if (!plan) {
        return res.status(404).json({ message: "Travel plan not found" });
      }
      res.json(plan);
    } catch (error) {
      console.error("Error updating travel plan:", error);
      res.status(500).json({ message: "Failed to update travel plan" });
    }
  });

  app.delete("/api/travel-plans/:id", isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteTravelPlan(id);
      if (!success) {
        return res.status(404).json({ message: "Travel plan not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting travel plan:", error);
      res.status(500).json({ message: "Failed to delete travel plan" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
