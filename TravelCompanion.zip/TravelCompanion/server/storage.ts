import {
  users,
  destinations,
  hotels,
  activities,
  bookings,
  reviews,
  travelPlans,
  type User,
  type UpsertUser,
  type Destination,
  type InsertDestination,
  type Hotel,
  type InsertHotel,
  type Activity,
  type InsertActivity,
  type Booking,
  type InsertBooking,
  type Review,
  type InsertReview,
  type TravelPlan,
  type InsertTravelPlan,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Destination operations
  getDestinations(): Promise<Destination[]>;
  getDestination(id: number): Promise<Destination | undefined>;
  searchDestinations(query: string): Promise<Destination[]>;
  createDestination(destination: InsertDestination): Promise<Destination>;

  // Hotel operations
  getHotels(destinationId?: number): Promise<Hotel[]>;
  getHotel(id: number): Promise<Hotel | undefined>;
  searchHotels(params: {
    destination?: string;
    checkIn?: string;
    checkOut?: string;
    guests?: number;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Hotel[]>;
  createHotel(hotel: InsertHotel): Promise<Hotel>;

  // Activity operations
  getActivities(destinationId?: number): Promise<Activity[]>;
  getActivity(id: number): Promise<Activity | undefined>;
  searchActivities(params: {
    destination?: string;
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Booking operations
  getUserBookings(userId: string): Promise<Booking[]>;
  getBooking(id: number): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;

  // Review operations
  getReviews(type: string, itemId: number): Promise<Review[]>;
  getUserReviews(userId: string): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;

  // Travel plan operations
  getUserTravelPlans(userId: string): Promise<TravelPlan[]>;
  getTravelPlan(id: number): Promise<TravelPlan | undefined>;
  createTravelPlan(plan: InsertTravelPlan): Promise<TravelPlan>;
  updateTravelPlan(id: number, updates: Partial<InsertTravelPlan>): Promise<TravelPlan | undefined>;
  deleteTravelPlan(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Destination operations
  async getDestinations(): Promise<Destination[]> {
    return await db.select().from(destinations).orderBy(desc(destinations.rating));
  }

  async getDestination(id: number): Promise<Destination | undefined> {
    const [destination] = await db
      .select()
      .from(destinations)
      .where(eq(destinations.id, id));
    return destination;
  }

  async searchDestinations(query: string): Promise<Destination[]> {
    return await db
      .select()
      .from(destinations)
      .where(
        sql`${destinations.nameKo} ILIKE ${'%' + query + '%'} OR ${destinations.countryKo} ILIKE ${'%' + query + '%'}`
      );
  }

  async createDestination(destination: InsertDestination): Promise<Destination> {
    const [created] = await db
      .insert(destinations)
      .values(destination)
      .returning();
    return created;
  }

  // Hotel operations
  async getHotels(destinationId?: number): Promise<Hotel[]> {
    const query = db.select().from(hotels);
    if (destinationId) {
      return await query.where(eq(hotels.destinationId, destinationId));
    }
    return await query.orderBy(desc(hotels.rating));
  }

  async getHotel(id: number): Promise<Hotel | undefined> {
    const [hotel] = await db.select().from(hotels).where(eq(hotels.id, id));
    return hotel;
  }

  async searchHotels(params: {
    destination?: string;
    checkIn?: string;
    checkOut?: string;
    guests?: number;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Hotel[]> {
    let query = db.select().from(hotels);
    const conditions = [];

    if (params.destination) {
      conditions.push(
        sql`${hotels.nameKo} ILIKE ${'%' + params.destination + '%'} OR ${hotels.addressKo} ILIKE ${'%' + params.destination + '%'}`
      );
    }

    if (params.minPrice) {
      conditions.push(gte(hotels.pricePerNight, params.minPrice));
    }

    if (params.maxPrice) {
      conditions.push(lte(hotels.pricePerNight, params.maxPrice));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query.orderBy(desc(hotels.rating));
  }

  async createHotel(hotel: InsertHotel): Promise<Hotel> {
    const [created] = await db.insert(hotels).values(hotel).returning();
    return created;
  }

  // Activity operations
  async getActivities(destinationId?: number): Promise<Activity[]> {
    const query = db.select().from(activities);
    if (destinationId) {
      return await query.where(eq(activities.destinationId, destinationId));
    }
    return await query.orderBy(desc(activities.rating));
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    const [activity] = await db
      .select()
      .from(activities)
      .where(eq(activities.id, id));
    return activity;
  }

  async searchActivities(params: {
    destination?: string;
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Activity[]> {
    let query = db.select().from(activities);
    const conditions = [];

    if (params.destination) {
      conditions.push(
        sql`${activities.nameKo} ILIKE ${'%' + params.destination + '%'}`
      );
    }

    if (params.category) {
      conditions.push(eq(activities.category, params.category));
    }

    if (params.minPrice) {
      conditions.push(gte(activities.price, params.minPrice));
    }

    if (params.maxPrice) {
      conditions.push(lte(activities.price, params.maxPrice));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query.orderBy(desc(activities.rating));
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [created] = await db.insert(activities).values(activity).returning();
    return created;
  }

  // Booking operations
  async getUserBookings(userId: string): Promise<Booking[]> {
    return await db
      .select()
      .from(bookings)
      .where(eq(bookings.userId, userId))
      .orderBy(desc(bookings.createdAt));
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [created] = await db.insert(bookings).values(booking).returning();
    return created;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const [updated] = await db
      .update(bookings)
      .set({ status, updatedAt: new Date() })
      .where(eq(bookings.id, id))
      .returning();
    return updated;
  }

  // Review operations
  async getReviews(type: string, itemId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(and(eq(reviews.type, type), eq(reviews.itemId, itemId)))
      .orderBy(desc(reviews.createdAt));
  }

  async getUserReviews(userId: string): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.userId, userId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [created] = await db.insert(reviews).values(review).returning();
    return created;
  }

  // Travel plan operations
  async getUserTravelPlans(userId: string): Promise<TravelPlan[]> {
    return await db
      .select()
      .from(travelPlans)
      .where(eq(travelPlans.userId, userId))
      .orderBy(desc(travelPlans.updatedAt));
  }

  async getTravelPlan(id: number): Promise<TravelPlan | undefined> {
    const [plan] = await db
      .select()
      .from(travelPlans)
      .where(eq(travelPlans.id, id));
    return plan;
  }

  async createTravelPlan(plan: InsertTravelPlan): Promise<TravelPlan> {
    const [created] = await db.insert(travelPlans).values(plan).returning();
    return created;
  }

  async updateTravelPlan(id: number, updates: Partial<InsertTravelPlan>): Promise<TravelPlan | undefined> {
    const [updated] = await db
      .update(travelPlans)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(travelPlans.id, id))
      .returning();
    return updated;
  }

  async deleteTravelPlan(id: number): Promise<boolean> {
    const result = await db.delete(travelPlans).where(eq(travelPlans.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
