import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import HotelCard from "@/components/HotelCard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Search, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { Hotel } from "@shared/schema";

export default function Hotels() {
  const [searchParams, setSearchParams] = useState({
    destination: "",
    checkIn: "",
    checkOut: "",
    guests: 1,
    minPrice: "",
    maxPrice: "",
  });
  const [showFilters, setShowFilters] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: hotels, isLoading, error } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "호텔 정보를 불러올 수 없습니다.",
        variant: "destructive",
      });
    },
  });

  const bookingMutation = useMutation({
    mutationFn: async (hotelData: { hotelId: number; checkIn: string; checkOut: string; guests: number }) => {
      await apiRequest("POST", "/api/bookings", {
        type: "hotel",
        itemId: hotelData.hotelId,
        checkIn: hotelData.checkIn,
        checkOut: hotelData.checkOut,
        guests: hotelData.guests,
        totalPrice: 0, // Will be calculated on server
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      toast({
        title: "예약 완료",
        description: "호텔 예약이 성공적으로 완료되었습니다!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "예약 실패",
        description: "호텔 예약 중 오류가 발생했습니다. 다시 시도해주세요.",
        variant: "destructive",
      });
    },
  });

  const filteredHotels = hotels?.filter(hotel => {
    const matchesDestination = !searchParams.destination || 
      hotel.nameKo.toLowerCase().includes(searchParams.destination.toLowerCase()) ||
      hotel.addressKo?.toLowerCase().includes(searchParams.destination.toLowerCase());
    
    const matchesMinPrice = !searchParams.minPrice || 
      hotel.pricePerNight >= parseInt(searchParams.minPrice);
    
    const matchesMaxPrice = !searchParams.maxPrice || 
      hotel.pricePerNight <= parseInt(searchParams.maxPrice);
    
    return matchesDestination && matchesMinPrice && matchesMaxPrice;
  });

  const handleBookHotel = (hotel: Hotel) => {
    if (!searchParams.checkIn || !searchParams.checkOut) {
      toast({
        title: "예약 정보 부족",
        description: "체크인/체크아웃 날짜를 먼저 선택해주세요.",
        variant: "destructive",
      });
      return;
    }

    bookingMutation.mutate({
      hotelId: hotel.id,
      checkIn: searchParams.checkIn,
      checkOut: searchParams.checkOut,
      guests: searchParams.guests,
    });
  };

  const handleSearch = () => {
    toast({
      title: "검색 완료",
      description: `${filteredHotels?.length || 0}개의 호텔을 찾았습니다.`,
    });
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">오류가 발생했습니다</h1>
            <p className="text-gray-600">호텔 정보를 불러올 수 없습니다. 나중에 다시 시도해주세요.</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            숙소 예약
          </h1>
          <p className="text-xl text-gray-600">
            편안하고 특별한 숙박 경험을 위한 최고의 호텔들
          </p>
        </div>

        {/* Search and Filter Section */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-4">
            <div>
              <Label htmlFor="destination">목적지</Label>
              <Input
                id="destination"
                placeholder="호텔명 또는 지역"
                value={searchParams.destination}
                onChange={(e) => setSearchParams(prev => ({ ...prev, destination: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="checkIn">체크인</Label>
              <Input
                id="checkIn"
                type="date"
                value={searchParams.checkIn}
                onChange={(e) => setSearchParams(prev => ({ ...prev, checkIn: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="checkOut">체크아웃</Label>
              <Input
                id="checkOut"
                type="date"
                value={searchParams.checkOut}
                onChange={(e) => setSearchParams(prev => ({ ...prev, checkOut: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="guests">인원</Label>
              <Select value={searchParams.guests.toString()} onValueChange={(value) => setSearchParams(prev => ({ ...prev, guests: parseInt(value) }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1명</SelectItem>
                  <SelectItem value="2">2명</SelectItem>
                  <SelectItem value="3">3명</SelectItem>
                  <SelectItem value="4">4명</SelectItem>
                  <SelectItem value="5">5명 이상</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={handleSearch} className="w-full bg-primary text-white">
                <Search className="mr-2 h-4 w-4" />
                검색
              </Button>
            </div>
          </div>

          {/* Advanced Filters */}
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              필터
            </Button>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t">
              <div>
                <Label htmlFor="minPrice">최소 가격 (원)</Label>
                <Input
                  id="minPrice"
                  type="number"
                  placeholder="0"
                  value={searchParams.minPrice}
                  onChange={(e) => setSearchParams(prev => ({ ...prev, minPrice: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="maxPrice">최대 가격 (원)</Label>
                <Input
                  id="maxPrice"
                  type="number"
                  placeholder="999999"
                  value={searchParams.maxPrice}
                  onChange={(e) => setSearchParams(prev => ({ ...prev, maxPrice: e.target.value }))}
                />
              </div>
            </div>
          )}
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-300 h-48 rounded-xl mb-4"></div>
                <div className="bg-gray-300 h-4 rounded mb-2"></div>
                <div className="bg-gray-300 h-4 rounded w-3/4"></div>
              </div>
            ))}
          </div>
        )}

        {/* Hotels Grid */}
        {!isLoading && filteredHotels && (
          <>
            <div className="mb-4 text-gray-600">
              {filteredHotels.length}개의 호텔을 찾았습니다
            </div>
            
            {filteredHotels.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  검색 조건에 맞는 호텔이 없습니다
                </h3>
                <p className="text-gray-600">
                  검색 조건을 조정해보세요
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredHotels.map((hotel) => (
                  <HotelCard
                    key={hotel.id}
                    hotel={hotel}
                    onBook={() => handleBookHotel(hotel)}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <Footer />
    </div>
  );
}
