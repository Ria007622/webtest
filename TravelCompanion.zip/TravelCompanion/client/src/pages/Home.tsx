import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import SearchBar from "@/components/SearchBar";
import DestinationCard from "@/components/DestinationCard";
import HotelCard from "@/components/HotelCard";
import ActivityCard from "@/components/ActivityCard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Destination, Hotel, Activity } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();

  const { data: destinations, isLoading: destinationsLoading } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "여행지 정보를 불러올 수 없습니다.",
        variant: "destructive",
      });
    },
  });

  const { data: hotels, isLoading: hotelsLoading } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) return;
      console.error("Error loading hotels:", error);
    },
  });

  const { data: activities, isLoading: activitiesLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) return;
      console.error("Error loading activities:", error);
    },
  });

  const handleSearch = (params: any) => {
    toast({
      title: "검색 시작",
      description: `${params.destination}로 검색 중...`,
    });
    // TODO: Implement search functionality
  };

  const handleBookHotel = (hotelId: number) => {
    toast({
      title: "예약 시작",
      description: "예약 페이지로 이동합니다...",
    });
    // TODO: Implement booking functionality
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Welcome Section */}
      <section className="relative">
        <div 
          className="h-96 md:h-[500px] bg-cover bg-center relative"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-40" />
          <div className="relative z-10 flex items-center justify-center h-full">
            <div className="text-center text-white px-4">
              <h1 className="text-3xl md:text-5xl font-bold mb-6">
                YOLO와 함께하는 특별한 여행
              </h1>
              <p className="text-lg md:text-xl mb-8 opacity-90">
                나만의 여행 계획을 세우고 잊을 수 없는 추억을 만들어보세요
              </p>
              
              <SearchBar
                onSearch={handleSearch}
                className="max-w-4xl mx-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link href="/destinations">
              <Button variant="outline" className="h-20 flex flex-col space-y-2">
                <span className="text-2xl">🌍</span>
                <span>여행지 둘러보기</span>
              </Button>
            </Link>
            <Link href="/hotels">
              <Button variant="outline" className="h-20 flex flex-col space-y-2">
                <span className="text-2xl">🏨</span>
                <span>숙소 예약</span>
              </Button>
            </Link>
            <Link href="/activities">
              <Button variant="outline" className="h-20 flex flex-col space-y-2">
                <span className="text-2xl">🎯</span>
                <span>액티비티</span>
              </Button>
            </Link>
            <Link href="/mypage">
              <Button variant="outline" className="h-20 flex flex-col space-y-2">
                <span className="text-2xl">📋</span>
                <span>내 여행 계획</span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
              인기 여행지
            </h2>
            <Link href="/destinations">
              <Button variant="ghost" className="text-primary">
                더보기 →
              </Button>
            </Link>
          </div>
          
          {destinationsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-300 h-64 rounded-xl mb-4"></div>
                  <div className="bg-gray-300 h-4 rounded mb-2"></div>
                  <div className="bg-gray-300 h-4 rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {destinations?.slice(0, 4).map((destination) => (
                <DestinationCard
                  key={destination.id}
                  destination={destination}
                  onClick={() => toast({ title: "상세 정보", description: `${destination.nameKo} 상세 페이지로 이동합니다.` })}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Hotels */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
              추천 숙소
            </h2>
            <Link href="/hotels">
              <Button variant="ghost" className="text-primary">
                더보기 →
              </Button>
            </Link>
          </div>
          
          {hotelsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-300 h-48 rounded-xl mb-4"></div>
                  <div className="bg-gray-300 h-4 rounded mb-2"></div>
                  <div className="bg-gray-300 h-4 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {hotels?.slice(0, 3).map((hotel) => (
                <HotelCard
                  key={hotel.id}
                  hotel={hotel}
                  onBook={() => handleBookHotel(hotel.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Popular Activities */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
              인기 액티비티
            </h2>
            <Link href="/activities">
              <Button variant="ghost" className="text-primary">
                더보기 →
              </Button>
            </Link>
          </div>
          
          {activitiesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-300 h-64 rounded-xl mb-4"></div>
                  <div className="bg-gray-300 h-4 rounded mb-2"></div>
                  <div className="bg-gray-300 h-4 rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activities?.slice(0, 3).map((activity) => (
                <ActivityCard
                  key={activity.id}
                  activity={activity}
                  onClick={() => toast({ title: "상세 정보", description: `${activity.nameKo} 상세 페이지로 이동합니다.` })}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
