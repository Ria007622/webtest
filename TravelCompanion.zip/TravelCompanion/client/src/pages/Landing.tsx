import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Star, Plane, MapPin, Camera, Calendar } from "lucide-react";

export default function Landing() {
  const handleSearch = (params: any) => {
    console.log("Search params:", params);
    // TODO: Implement search functionality
  };

  // Sample data for the landing page
  const destinations = [
    {
      id: 1,
      nameKo: "도쿄",
      countryKo: "일본",
      imageUrl: "https://images.unsplash.com/photo-1590559899731-a382839e5549?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      rating: "4.8"
    },
    {
      id: 2,
      nameKo: "파리",
      countryKo: "프랑스",
      imageUrl: "https://images.unsplash.com/photo-1549144511-f099e773c147?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      rating: "4.9"
    },
    {
      id: 3,
      nameKo: "몰디브",
      countryKo: "인도양",
      imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      rating: "4.7"
    },
    {
      id: 4,
      nameKo: "로마",
      countryKo: "이탈리아",
      imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      rating: "4.6"
    }
  ];

  const hotels = [
    {
      id: 1,
      nameKo: "그랜드 호텔 서울",
      location: "강남구 • 시티뷰",
      price: 180000,
      rating: "4.8",
      imageUrl: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
    },
    {
      id: 2,
      nameKo: "부티크 호텔 제주",
      location: "제주시 • 오션뷰",
      price: 250000,
      rating: "4.9",
      imageUrl: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
    },
    {
      id: 3,
      nameKo: "한옥 스테이 경주",
      location: "경주시 • 전통 한옥",
      price: 120000,
      rating: "4.7",
      imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
    }
  ];

  const activities = [
    {
      id: 1,
      nameKo: "스카이다이빙",
      price: 350000,
      imageUrl: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
    },
    {
      id: 2,
      nameKo: "스쿠버 다이빙",
      price: 120000,
      imageUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
    },
    {
      id: 3,
      nameKo: "산악 하이킹",
      price: 85000,
      imageUrl: "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
    }
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'KRW',
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="relative">
        <div 
          className="h-96 md:h-[600px] bg-cover bg-center relative"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-40" />
          <div className="relative z-10 flex items-center justify-center h-full">
            <div className="text-center text-white px-4">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                당신만의 YOLO 여행을 시작하세요
              </h1>
              <p className="text-xl md:text-2xl mb-8 opacity-90">
                전 세계 최고의 여행지에서 특별한 추억을 만들어보세요
              </p>
              
              <SearchBar
                onSearch={handleSearch}
                className="max-w-4xl mx-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              인기 여행지
            </h2>
            <p className="text-xl text-gray-600">
              전 세계 여행자들이 선택한 최고의 여행지
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {destinations.map((destination) => (
              <div key={destination.id} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-xl h-64 shadow-lg group-hover:shadow-xl transition-shadow">
                  <img
                    src={destination.imageUrl}
                    alt={destination.nameKo}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-bold">{destination.nameKo}</h3>
                    <p className="text-sm opacity-90">{destination.countryKo}</p>
                  </div>
                  <div className="absolute top-4 right-4 bg-white/90 text-gray-900 px-2 py-1 rounded-full text-sm flex items-center">
                    <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
                    {destination.rating}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Hotel Section */}
      <section className="py-16 bg-yolo-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              추천 숙소
            </h2>
            <p className="text-xl text-gray-600">
              편안하고 특별한 숙박 경험을 제공하는 호텔
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {hotels.map((hotel) => (
              <Card key={hotel.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                <img
                  src={hotel.imageUrl}
                  alt={hotel.nameKo}
                  className="w-full h-48 object-cover"
                />
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{hotel.nameKo}</h3>
                    <div className="flex items-center text-yellow-500">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="text-gray-700 ml-1">{hotel.rating}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4 flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {hotel.location}
                  </p>
                  <div className="flex justify-between items-center">
                    <div className="text-2xl font-bold text-primary">
                      {formatPrice(hotel.price)}
                    </div>
                    <Button
                      className="bg-primary text-white hover:bg-blue-600"
                      onClick={() => window.location.href = "/api/login"}
                    >
                      예약하기
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Activities Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              체험 액티비티
            </h2>
            <p className="text-xl text-gray-600">
              잊을 수 없는 추억을 만들어줄 특별한 체험
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {activities.map((activity) => (
              <div key={activity.id} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-xl shadow-lg">
                  <img
                    src={activity.imageUrl}
                    alt={activity.nameKo}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-bold mb-2">{activity.nameKo}</h3>
                    <p className="text-sm opacity-90">{formatPrice(activity.price)}부터</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Travel Planning Section */}
      <section className="py-16 bg-yolo-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              여행 계획하기
            </h2>
            <p className="text-xl text-gray-600">
              완벽한 여행을 위한 단계별 가이드
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "1",
                title: "계획 세우기",
                description: "목적지 선택부터 일정 구성까지",
                icon: <Calendar className="h-8 w-8 text-primary" />,
                image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              },
              {
                step: "2",
                title: "예약하기",
                description: "항공권과 숙소를 간편하게",
                icon: <Plane className="h-8 w-8 text-primary" />,
                image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              },
              {
                step: "3",
                title: "준비하기",
                description: "여행 준비물과 체크리스트",
                icon: <MapPin className="h-8 w-8 text-primary" />,
                image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              },
              {
                step: "4",
                title: "즐기기",
                description: "잊을 수 없는 추억 만들기",
                icon: <Camera className="h-8 w-8 text-primary" />,
                image: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              }
            ].map((item) => (
              <div key={item.step} className="text-center">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-48 object-cover rounded-xl shadow-lg mb-4"
                />
                <div className="flex justify-center mb-2">{item.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {item.step}. {item.title}
                </h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            지금 바로 YOLO와 함께 떠나세요!
          </h2>
          <p className="text-xl mb-8 opacity-90">
            전 세계 어디든, 당신만의 특별한 여행이 기다리고 있습니다
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="secondary"
              size="lg"
              className="bg-white text-primary hover:bg-gray-100"
              onClick={() => window.location.href = "/api/login"}
            >
              여행 상품 둘러보기
            </Button>
            <Button
              size="lg"
              className="bg-yolo-accent text-white hover:bg-red-500"
              onClick={() => window.location.href = "/api/login"}
            >
              지금 회원가입하기
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
