import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Calendar, MapPin, Star, Plus, Edit, Trash2, Plane, Hotel, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import type { Booking, Review, TravelPlan, Destination } from "@shared/schema";

const travelPlanSchema = z.object({
  name: z.string().min(1, "여행 계획 이름을 입력해주세요"),
  description: z.string().optional(),
  destinationId: z.number().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  budget: z.number().optional(),
  isPublic: z.boolean().default(false),
});

type TravelPlanFormData = z.infer<typeof travelPlanSchema>;

export default function MyPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [isCreatePlanDialogOpen, setIsCreatePlanDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<TravelPlan | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isAuthenticated } = useAuth();

  // Queries for user data
  const { data: bookings, isLoading: bookingsLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const { data: reviews, isLoading: reviewsLoading } = useQuery<Review[]>({
    queryKey: ["/api/reviews/user"],
    enabled: isAuthenticated,
  });

  const { data: travelPlans, isLoading: plansLoading } = useQuery<TravelPlan[]>({
    queryKey: ["/api/travel-plans"],
    enabled: isAuthenticated,
  });

  const { data: destinations } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  const form = useForm<TravelPlanFormData>({
    resolver: zodResolver(travelPlanSchema),
    defaultValues: {
      name: "",
      description: "",
      isPublic: false,
    },
  });

  // Mutations
  const createPlanMutation = useMutation({
    mutationFn: async (data: TravelPlanFormData) => {
      await apiRequest("POST", "/api/travel-plans", {
        ...data,
        startDate: data.startDate ? new Date(data.startDate) : undefined,
        endDate: data.endDate ? new Date(data.endDate) : undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/travel-plans"] });
      toast({
        title: "여행 계획 생성 완료",
        description: "새로운 여행 계획이 생성되었습니다!",
      });
      setIsCreatePlanDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "생성 실패",
        description: "여행 계획 생성 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: TravelPlanFormData }) => {
      await apiRequest("PUT", `/api/travel-plans/${id}`, {
        ...data,
        startDate: data.startDate ? new Date(data.startDate) : undefined,
        endDate: data.endDate ? new Date(data.endDate) : undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/travel-plans"] });
      toast({
        title: "여행 계획 수정 완료",
        description: "여행 계획이 성공적으로 수정되었습니다!",
      });
      setEditingPlan(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "수정 실패",
        description: "여행 계획 수정 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/travel-plans/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/travel-plans"] });
      toast({
        title: "여행 계획 삭제 완료",
        description: "여행 계획이 삭제되었습니다.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "삭제 실패",
        description: "여행 계획 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'KRW',
    }).format(price);
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "";
    return new Intl.DateTimeFormat('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(new Date(date));
  };

  const getBookingStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: "대기 중", variant: "secondary" as const },
      confirmed: { label: "확정", variant: "default" as const },
      cancelled: { label: "취소됨", variant: "destructive" as const },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.pending;
    
    return (
      <Badge variant={statusInfo.variant}>
        {statusInfo.label}
      </Badge>
    );
  };

  const handleEditPlan = (plan: TravelPlan) => {
    setEditingPlan(plan);
    form.reset({
      name: plan.name,
      description: plan.description || "",
      destinationId: plan.destinationId || undefined,
      startDate: plan.startDate ? new Date(plan.startDate).toISOString().split('T')[0] : "",
      endDate: plan.endDate ? new Date(plan.endDate).toISOString().split('T')[0] : "",
      budget: plan.budget || undefined,
      isPublic: plan.isPublic || false,
    });
    setIsCreatePlanDialogOpen(true);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">로그인이 필요합니다</h1>
            <p className="text-gray-600 mb-8">마이페이지를 이용하려면 로그인해주세요.</p>
            <Button onClick={() => window.location.href = "/api/login"}>
              로그인하기
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* User Profile Section */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6">
              <Avatar className="h-20 w-20">
                <AvatarImage src={user?.profileImageUrl || ""} alt="Profile" />
                <AvatarFallback className="text-xl">
                  {user?.firstName?.[0] || user?.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {user?.firstName && user?.lastName 
                    ? `${user.firstName} ${user.lastName}`
                    : user?.email || "사용자"
                  }님의 여행 공간
                </h1>
                <p className="text-gray-600 mt-1">
                  YOLO와 함께하는 특별한 여행을 계획하고 관리해보세요
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">전체 현황</TabsTrigger>
            <TabsTrigger value="bookings">예약 현황</TabsTrigger>
            <TabsTrigger value="reviews">내 후기</TabsTrigger>
            <TabsTrigger value="plans">여행 계획</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">총 예약</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {bookings?.length || 0}
                      </p>
                    </div>
                    <Hotel className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">작성한 후기</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {reviews?.length || 0}
                      </p>
                    </div>
                    <Star className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">여행 계획</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {travelPlans?.length || 0}
                      </p>
                    </div>
                    <MapPin className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>최근 활동</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bookings?.slice(0, 3).map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                      <div className="flex items-center space-x-3">
                        {booking.type === "hotel" ? (
                          <Hotel className="h-5 w-5 text-primary" />
                        ) : (
                          <Activity className="h-5 w-5 text-primary" />
                        )}
                        <div>
                          <p className="font-medium">
                            {booking.type === "hotel" ? "호텔" : "액티비티"} 예약
                          </p>
                          <p className="text-sm text-gray-600">
                            {formatDate(booking.createdAt)}
                          </p>
                        </div>
                      </div>
                      {getBookingStatusBadge(booking.status || "pending")}
                    </div>
                  ))}
                  
                  {(!bookings || bookings.length === 0) && (
                    <p className="text-gray-500 text-center py-8">
                      아직 예약 내역이 없습니다.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">예약 현황</h2>
            </div>
            
            {bookingsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-300 h-32 rounded-xl"></div>
                  </div>
                ))}
              </div>
            ) : bookings && bookings.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {bookings.map((booking) => (
                  <Card key={booking.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center space-x-3">
                          {booking.type === "hotel" ? (
                            <Hotel className="h-6 w-6 text-primary" />
                          ) : (
                            <Activity className="h-6 w-6 text-primary" />
                          )}
                          <div>
                            <h3 className="font-bold">
                              {booking.type === "hotel" ? "호텔" : "액티비티"} 예약
                            </h3>
                            <p className="text-sm text-gray-600">
                              예약 ID: {booking.id}
                            </p>
                          </div>
                        </div>
                        {getBookingStatusBadge(booking.status || "pending")}
                      </div>
                      
                      {booking.checkIn && booking.checkOut && (
                        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                          <Calendar className="h-4 w-4" />
                          <span>
                            {formatDate(booking.checkIn)} - {formatDate(booking.checkOut)}
                          </span>
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center">
                        <span className="text-lg font-bold text-primary">
                          {formatPrice(booking.totalPrice)}
                        </span>
                        <span className="text-sm text-gray-600">
                          {booking.guests}명
                        </span>
                      </div>
                      
                      {booking.specialRequests && (
                        <p className="text-sm text-gray-600 mt-2">
                          특별 요청: {booking.specialRequests}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Hotel className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  아직 예약 내역이 없습니다
                </h3>
                <p className="text-gray-600">
                  첫 번째 여행을 예약해보세요!
                </p>
              </div>
            )}
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">내가 작성한 후기</h2>
            </div>
            
            {reviewsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-300 h-32 rounded-xl"></div>
                  </div>
                ))}
              </div>
            ) : reviews && reviews.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-bold">{review.title}</h3>
                          <div className="flex items-center space-x-2 mt-1">
                            <div className="flex">
                              {Array.from({ length: 5 }, (_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating
                                      ? "fill-yellow-400 text-yellow-400"
                                      : "text-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                            <Badge variant="secondary" className="text-xs">
                              {review.type === "hotel" ? "호텔" : 
                               review.type === "activity" ? "액티비티" : "여행지"}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      {review.content && (
                        <p className="text-gray-600 text-sm line-clamp-3 mb-4">
                          {review.content}
                        </p>
                      )}
                      
                      <div className="text-xs text-gray-400">
                        {formatDate(review.createdAt)}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Star className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  아직 작성한 후기가 없습니다
                </h3>
                <p className="text-gray-600">
                  여행 경험을 공유해보세요!
                </p>
              </div>
            )}
          </TabsContent>

          {/* Travel Plans Tab */}
          <TabsContent value="plans" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">나의 여행 계획</h2>
              
              <Dialog open={isCreatePlanDialogOpen} onOpenChange={(open) => {
                setIsCreatePlanDialogOpen(open);
                if (!open) {
                  setEditingPlan(null);
                  form.reset();
                }
              }}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-white">
                    <Plus className="mr-2 h-4 w-4" />
                    새 계획 만들기
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      {editingPlan ? "여행 계획 수정" : "새 여행 계획"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form 
                      onSubmit={form.handleSubmit((data) => {
                        if (editingPlan) {
                          updatePlanMutation.mutate({ id: editingPlan.id, data });
                        } else {
                          createPlanMutation.mutate(data);
                        }
                      })} 
                      className="space-y-6"
                    >
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>계획 이름</FormLabel>
                            <FormControl>
                              <Input placeholder="예: 제주도 3박 4일 여행" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>설명</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="여행 계획에 대한 설명을 입력하세요"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="destinationId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>목적지</FormLabel>
                            <Select 
                              onValueChange={(value) => field.onChange(parseInt(value))}
                              value={field.value?.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="목적지를 선택하세요" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {destinations?.map((destination) => (
                                  <SelectItem key={destination.id} value={destination.id.toString()}>
                                    {destination.nameKo}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>시작일</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>종료일</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="budget"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>예산 (원)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="1000000"
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end gap-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsCreatePlanDialogOpen(false)}
                        >
                          취소
                        </Button>
                        <Button
                          type="submit"
                          disabled={createPlanMutation.isPending || updatePlanMutation.isPending}
                          className="bg-primary text-white"
                        >
                          {createPlanMutation.isPending || updatePlanMutation.isPending
                            ? "저장 중..." 
                            : editingPlan ? "수정하기" : "만들기"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
            
            {plansLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-300 h-48 rounded-xl"></div>
                  </div>
                ))}
              </div>
            ) : travelPlans && travelPlans.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {travelPlans.map((plan) => (
                  <Card key={plan.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-bold">{plan.name}</h3>
                          {plan.description && (
                            <p className="text-gray-600 text-sm mt-1 line-clamp-2">
                              {plan.description}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditPlan(plan)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => deletePlanMutation.mutate(plan.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      {plan.startDate && plan.endDate && (
                        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                          <Calendar className="h-4 w-4" />
                          <span>
                            {formatDate(plan.startDate)} - {formatDate(plan.endDate)}
                          </span>
                        </div>
                      )}
                      
                      {plan.budget && (
                        <div className="text-lg font-bold text-primary mb-2">
                          예산: {formatPrice(plan.budget)}
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center">
                        <div className="text-xs text-gray-400">
                          {formatDate(plan.updatedAt)}
                        </div>
                        {plan.isPublic && (
                          <Badge variant="secondary">공개</Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <MapPin className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  아직 여행 계획이 없습니다
                </h3>
                <p className="text-gray-600 mb-6">
                  첫 번째 여행 계획을 만들어보세요!
                </p>
                <Button
                  onClick={() => setIsCreatePlanDialogOpen(true)}
                  className="bg-primary text-white"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  계획 만들기
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  );
}
