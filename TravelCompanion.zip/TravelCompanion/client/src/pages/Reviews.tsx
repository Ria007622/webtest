import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ReviewCard from "@/components/ReviewCard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Star, Plus, Filter, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import type { Review, Destination, Hotel, Activity } from "@shared/schema";

const reviewSchema = z.object({
  type: z.enum(["destination", "hotel", "activity"]),
  itemId: z.number(),
  rating: z.number().min(1).max(5),
  title: z.string().min(1, "제목을 입력해주세요"),
  content: z.string().min(10, "최소 10자 이상 입력해주세요"),
});

type ReviewFormData = z.infer<typeof reviewSchema>;

export default function Reviews() {
  const [selectedType, setSelectedType] = useState<"destination" | "hotel" | "activity">("destination");
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isAuthenticated } = useAuth();

  // Fetch reviews for different types
  const { data: destinationReviews, isLoading: destinationLoading } = useQuery<Review[]>({
    queryKey: ["/api/reviews/user"],
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  // Fetch available items for review creation
  const { data: destinations } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  const { data: hotels } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels"],
  });

  const { data: activities } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });

  const form = useForm<ReviewFormData>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      type: "destination",
      rating: 5,
      title: "",
      content: "",
    },
  });

  const createReviewMutation = useMutation({
    mutationFn: async (data: ReviewFormData) => {
      await apiRequest("POST", "/api/reviews", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      toast({
        title: "리뷰 작성 완료",
        description: "소중한 후기를 공유해주셔서 감사합니다!",
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "리뷰 작성 실패",
        description: "리뷰 작성 중 오류가 발생했습니다. 다시 시도해주세요.",
        variant: "destructive",
      });
    },
  });

  const filteredReviews = destinationReviews?.filter(review => {
    const matchesType = review.type === selectedType;
    const matchesSearch = !searchQuery || 
      review.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.content?.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesType && matchesSearch;
  });

  const getAvailableItems = () => {
    switch (form.watch("type")) {
      case "destination":
        return destinations || [];
      case "hotel":
        return hotels || [];
      case "activity":
        return activities || [];
      default:
        return [];
    }
  };

  const renderStars = (rating: number, interactive = false, onRatingChange?: (rating: number) => void) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-6 w-6 cursor-pointer transition-colors ${
          i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300 hover:text-yellow-400"
        }`}
        onClick={() => interactive && onRatingChange?.(i + 1)}
      />
    ));
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">로그인이 필요합니다</h1>
            <p className="text-gray-600 mb-8">여행 후기를 보고 작성하려면 로그인해주세요.</p>
            <Button onClick={() => window.location.href = "/api/login"}>
              로그인하기
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              여행 후기
            </h1>
            <p className="text-xl text-gray-600">
              실제 여행자들의 생생한 경험담을 확인하고 나만의 후기를 공유하세요
            </p>
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-white">
                <Plus className="mr-2 h-4 w-4" />
                후기 작성
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>여행 후기 작성</DialogTitle>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createReviewMutation.mutate(data))} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>리뷰 유형</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="리뷰 유형을 선택하세요" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="destination">여행지</SelectItem>
                            <SelectItem value="hotel">호텔</SelectItem>
                            <SelectItem value="activity">액티비티</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="itemId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          {form.watch("type") === "destination" && "여행지 선택"}
                          {form.watch("type") === "hotel" && "호텔 선택"}
                          {form.watch("type") === "activity" && "액티비티 선택"}
                        </FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="선택하세요" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {getAvailableItems().map((item: any) => (
                              <SelectItem key={item.id} value={item.id.toString()}>
                                {item.nameKo || item.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>평점</FormLabel>
                        <FormControl>
                          <div className="flex items-center gap-2">
                            {renderStars(field.value, true, field.onChange)}
                            <span className="ml-2 text-lg font-medium">{field.value}/5</span>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>제목</FormLabel>
                        <FormControl>
                          <Input placeholder="후기 제목을 입력하세요" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>내용</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="여행 경험을 자세히 공유해주세요"
                            className="min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end gap-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      취소
                    </Button>
                    <Button
                      type="submit"
                      disabled={createReviewMutation.isPending}
                      className="bg-primary text-white"
                    >
                      {createReviewMutation.isPending ? "작성 중..." : "후기 작성"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and Filter Section */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  placeholder="후기 제목이나 내용으로 검색..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <Select value={selectedType} onValueChange={(value: any) => setSelectedType(value)}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="destination">여행지</SelectItem>
                  <SelectItem value="hotel">호텔</SelectItem>
                  <SelectItem value="activity">액티비티</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Reviews Content */}
        <Tabs value="my-reviews" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="my-reviews">내 후기</TabsTrigger>
            <TabsTrigger value="all-reviews">전체 후기</TabsTrigger>
          </TabsList>
          
          <TabsContent value="my-reviews" className="space-y-6">
            {destinationLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-300 h-48 rounded-xl"></div>
                  </div>
                ))}
              </div>
            ) : filteredReviews && filteredReviews.length > 0 ? (
              <>
                <div className="text-gray-600 mb-4">
                  {filteredReviews.length}개의 후기를 찾았습니다
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredReviews.map((review) => (
                    <ReviewCard key={review.id} review={review} showUserInfo={false} />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  아직 작성한 후기가 없습니다
                </h3>
                <p className="text-gray-600 mb-6">
                  첫 번째 여행 후기를 작성해보세요!
                </p>
                <Button
                  onClick={() => setIsCreateDialogOpen(true)}
                  className="bg-primary text-white"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  후기 작성하기
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="all-reviews" className="space-y-6">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                전체 후기 기능
              </h3>
              <p className="text-gray-600">
                전체 사용자의 후기를 확인하는 기능은 준비 중입니다.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  );
}
