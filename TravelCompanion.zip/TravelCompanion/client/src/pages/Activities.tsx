import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ActivityCard from "@/components/ActivityCard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Search, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Activity } from "@shared/schema";

export default function Activities() {
  const [searchParams, setSearchParams] = useState({
    destination: "",
    category: "",
    minPrice: "",
    maxPrice: "",
  });
  const [showFilters, setShowFilters] = useState(false);
  
  const { toast } = useToast();

  const { data: activities, isLoading, error } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "로그인이 필요합니다",
          description: "로그인 페이지로 이동합니다...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "오류",
        description: "액티비티 정보를 불러올 수 없습니다.",
        variant: "destructive",
      });
    },
  });

  const filteredActivities = activities?.filter(activity => {
    const matchesDestination = !searchParams.destination || 
      activity.nameKo.toLowerCase().includes(searchParams.destination.toLowerCase());
    
    const matchesCategory = !searchParams.category || 
      activity.category === searchParams.category;
    
    const matchesMinPrice = !searchParams.minPrice || 
      activity.price >= parseInt(searchParams.minPrice);
    
    const matchesMaxPrice = !searchParams.maxPrice || 
      activity.price <= parseInt(searchParams.maxPrice);
    
    return matchesDestination && matchesCategory && matchesMinPrice && matchesMaxPrice;
  });

  const handleActivityClick = (activity: Activity) => {
    toast({
      title: activity.nameKo,
      description: "액티비티 상세 정보를 확인해보세요!",
    });
    // TODO: Navigate to activity detail page or booking
  };

  const handleSearch = () => {
    toast({
      title: "검색 완료",
      description: `${filteredActivities?.length || 0}개의 액티비티를 찾았습니다.`,
    });
  };

  const categories = [...new Set(activities?.map(activity => activity.category).filter(Boolean))];

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">오류가 발생했습니다</h1>
            <p className="text-gray-600">액티비티 정보를 불러올 수 없습니다. 나중에 다시 시도해주세요.</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            체험 액티비티
          </h1>
          <p className="text-xl text-gray-600">
            잊을 수 없는 추억을 만들어줄 특별한 체험들
          </p>
        </div>

        {/* Search and Filter Section */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div>
              <Label htmlFor="destination">액티비티명</Label>
              <Input
                id="destination"
                placeholder="액티비티명으로 검색"
                value={searchParams.destination}
                onChange={(e) => setSearchParams(prev => ({ ...prev, destination: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="category">카테고리</Label>
              <Select value={searchParams.category} onValueChange={(value) => setSearchParams(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="카테고리 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">전체</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category!}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="priceRange">가격대</Label>
              <Select onValueChange={(value) => {
                const [min, max] = value.split('-');
                setSearchParams(prev => ({ ...prev, minPrice: min, maxPrice: max }));
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="가격대 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">전체</SelectItem>
                  <SelectItem value="0-100000">10만원 이하</SelectItem>
                  <SelectItem value="100000-200000">10-20만원</SelectItem>
                  <SelectItem value="200000-300000">20-30만원</SelectItem>
                  <SelectItem value="300000-999999">30만원 이상</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button onClick={handleSearch} className="w-full bg-primary text-white">
                <Search className="mr-2 h-4 w-4" />
                검색
              </Button>
            </div>
          </div>

          {/* Advanced Filters */}
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              상세 필터
            </Button>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t">
              <div>
                <Label htmlFor="minPrice">최소 가격 (원)</Label>
                <Input
                  id="minPrice"
                  type="number"
                  placeholder="0"
                  value={searchParams.minPrice}
                  onChange={(e) => setSearchParams(prev => ({ ...prev, minPrice: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="maxPrice">최대 가격 (원)</Label>
                <Input
                  id="maxPrice"
                  type="number"
                  placeholder="999999"
                  value={searchParams.maxPrice}
                  onChange={(e) => setSearchParams(prev => ({ ...prev, maxPrice: e.target.value }))}
                />
              </div>
            </div>
          )}
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-300 h-64 rounded-xl mb-4"></div>
                <div className="bg-gray-300 h-4 rounded mb-2"></div>
                <div className="bg-gray-300 h-4 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        )}

        {/* Activities Grid */}
        {!isLoading && filteredActivities && (
          <>
            <div className="mb-4 text-gray-600">
              {filteredActivities.length}개의 액티비티를 찾았습니다
            </div>
            
            {filteredActivities.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  검색 조건에 맞는 액티비티가 없습니다
                </h3>
                <p className="text-gray-600">
                  검색 조건을 조정해보세요
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredActivities.map((activity) => (
                  <ActivityCard
                    key={activity.id}
                    activity={activity}
                    onClick={() => handleActivityClick(activity)}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <Footer />
    </div>
  );
}
