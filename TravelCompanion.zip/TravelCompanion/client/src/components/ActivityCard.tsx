import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, Users } from "lucide-react";
import type { Activity } from "@shared/schema";

interface ActivityCardProps {
  activity: Activity;
  onClick?: () => void;
}

export default function ActivityCard({ activity, onClick }: ActivityCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'KRW',
    }).format(price);
  };

  return (
    <Card className="group cursor-pointer hover:shadow-xl transition-shadow" onClick={onClick}>
      <div className="relative overflow-hidden rounded-t-xl h-64">
        <img
          src={activity.imageUrl || "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"}
          alt={activity.nameKo}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        
        <div className="absolute bottom-4 left-4 text-white">
          <h3 className="text-xl font-bold mb-2">{activity.nameKo}</h3>
          <p className="text-sm opacity-90">{formatPrice(activity.price)}부터</p>
        </div>
        
        {activity.rating && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-white/90 text-gray-900">
              <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
              {activity.rating}
            </Badge>
          </div>
        )}
        
        {activity.category && (
          <div className="absolute top-4 left-4">
            <Badge className="bg-primary/90 text-white">
              {activity.category}
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
          {activity.duration && (
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {activity.duration}
            </div>
          )}
          {activity.difficulty && (
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-1" />
              {activity.difficulty}
            </div>
          )}
        </div>
        
        {activity.descriptionKo && (
          <p className="text-gray-600 text-sm line-clamp-2">{activity.descriptionKo}</p>
        )}
        
        {activity.reviewCount > 0 && (
          <p className="text-xs text-gray-500 mt-2">{activity.reviewCount}개의 리뷰</p>
        )}
      </CardContent>
    </Card>
  );
}
