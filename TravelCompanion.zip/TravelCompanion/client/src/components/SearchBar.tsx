import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search } from "lucide-react";

interface SearchBarProps {
  onSearch: (params: {
    destination: string;
    checkIn: string;
    checkOut: string;
    guests: number;
  }) => void;
  className?: string;
}

export default function SearchBar({ onSearch, className = "" }: SearchBarProps) {
  const [destination, setDestination] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({ destination, checkIn, checkOut, guests });
  };

  return (
    <div className={`bg-white rounded-xl p-6 shadow-2xl ${className}`}>
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-2">
              목적지
            </Label>
            <Input
              id="destination"
              type="text"
              placeholder="어디로 가시나요?"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="relative">
            <Label htmlFor="checkIn" className="block text-sm font-medium text-gray-700 mb-2">
              체크인
            </Label>
            <Input
              id="checkIn"
              type="date"
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="relative">
            <Label htmlFor="checkOut" className="block text-sm font-medium text-gray-700 mb-2">
              체크아웃
            </Label>
            <Input
              id="checkOut"
              type="date"
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="flex items-end">
            <Button type="submit" className="w-full bg-primary text-white hover:bg-blue-600">
              <Search className="mr-2 h-4 w-4" />
              검색
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
