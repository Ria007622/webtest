import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin } from "lucide-react";
import type { Hotel } from "@shared/schema";

interface HotelCardProps {
  hotel: Hotel;
  onBook?: () => void;
}

export default function HotelCard({ hotel, onBook }: HotelCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'KRW',
    }).format(price);
  };

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow">
      <div className="relative h-48">
        <img
          src={hotel.imageUrl || "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"}
          alt={hotel.nameKo}
          className="w-full h-full object-cover"
        />
        {hotel.rating && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-white/90 text-gray-900">
              <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
              {hotel.rating}
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-900">{hotel.nameKo}</h3>
        </div>
        
        {hotel.addressKo && (
          <div className="flex items-center text-gray-600 mb-4">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="text-sm">{hotel.addressKo}</span>
          </div>
        )}
        
        {hotel.amenities && hotel.amenities.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {hotel.amenities.slice(0, 3).map((amenity, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {amenity}
              </Badge>
            ))}
          </div>
        )}
        
        <div className="flex justify-between items-center">
          <div className="text-2xl font-bold text-primary">
            {formatPrice(hotel.pricePerNight)}
            <span className="text-sm font-normal text-gray-500">/박</span>
          </div>
          <Button
            onClick={onBook}
            className="bg-primary text-white hover:bg-blue-600"
          >
            예약하기
          </Button>
        </div>
        
        {hotel.reviewCount > 0 && (
          <p className="text-xs text-gray-500 mt-2">{hotel.reviewCount}개의 리뷰</p>
        )}
      </CardContent>
    </Card>
  );
}
