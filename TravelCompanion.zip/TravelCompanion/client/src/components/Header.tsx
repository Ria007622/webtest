import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Plane, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Header() {
  const { isAuthenticated, user } = useAuth();
  const [location] = useLocation();

  const navItems = [
    { href: "/destinations", label: "여행지" },
    { href: "/hotels", label: "숙소" },
    { href: "/activities", label: "액티비티" },
    { href: "/reviews", label: "여행후기" },
  ];

  return (
    <header className="bg-primary text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-8">
            <Link href="/">
              <div className="flex items-center space-x-2 text-2xl font-bold cursor-pointer">
                <Plane className="h-6 w-6" />
                <span>YOLO</span>
              </div>
            </Link>
            <nav className="hidden md:flex space-x-6">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <a
                    className={`hover:text-blue-200 transition-colors ${
                      location === item.href ? "text-blue-200" : ""
                    }`}
                  >
                    {item.label}
                  </a>
                </Link>
              ))}
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link href="/mypage">
                  <Button variant="ghost" className="text-white hover:bg-white/10">
                    마이페이지
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                  onClick={() => (window.location.href = "/api/logout")}
                >
                  로그아웃
                </Button>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  className="text-white hover:bg-white/10"
                  onClick={() => (window.location.href = "/api/login")}
                >
                  로그인
                </Button>
                <Button
                  className="bg-yolo-accent text-white hover:bg-red-500"
                  onClick={() => (window.location.href = "/api/login")}
                >
                  회원가입
                </Button>
              </>
            )}
            
            {/* Mobile menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden text-white">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px]">
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <a className="text-lg font-medium hover:text-primary transition-colors">
                        {item.label}
                      </a>
                    </Link>
                  ))}
                  {isAuthenticated && (
                    <Link href="/mypage">
                      <a className="text-lg font-medium hover:text-primary transition-colors">
                        마이페이지
                      </a>
                    </Link>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
