import { Link } from "wouter";
import { Plane, Facebook, Instagram, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 text-2xl font-bold mb-4">
              <Plane className="h-6 w-6" />
              <span>YOLO</span>
            </div>
            <p className="text-gray-400 mb-4">당신만의 특별한 여행을 시작하세요</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">여행 서비스</h3>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/destinations"><a className="hover:text-white transition-colors">여행지 둘러보기</a></Link></li>
              <li><Link href="/hotels"><a className="hover:text-white transition-colors">호텔 예약</a></Link></li>
              <li><Link href="/activities"><a className="hover:text-white transition-colors">액티비티</a></Link></li>
              <li><Link href="/reviews"><a className="hover:text-white transition-colors">여행 후기</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">고객 지원</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">고객센터</a></li>
              <li><a href="#" className="hover:text-white transition-colors">자주 묻는 질문</a></li>
              <li><a href="#" className="hover:text-white transition-colors">예약 확인</a></li>
              <li><a href="#" className="hover:text-white transition-colors">취소/환불</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">회사 정보</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">회사 소개</a></li>
              <li><a href="#" className="hover:text-white transition-colors">채용 정보</a></li>
              <li><a href="#" className="hover:text-white transition-colors">이용약관</a></li>
              <li><a href="#" className="hover:text-white transition-colors">개인정보처리방침</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 YOLO Travel. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
