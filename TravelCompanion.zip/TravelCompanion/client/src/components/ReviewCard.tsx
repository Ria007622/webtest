import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import type { Review } from "@shared/schema";

interface ReviewCardProps {
  review: Review;
  showUserInfo?: boolean;
}

export default function ReviewCard({ review, showUserInfo = true }: ReviewCardProps) {
  const formatDate = (date: Date | null) => {
    if (!date) return "";
    return new Intl.DateTimeFormat('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(new Date(date));
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <Card className="border">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          {showUserInfo && (
            <Avatar className="h-12 w-12 mr-4">
              <AvatarImage src="" alt="User" />
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
          )}
          <div className="flex-1">
            <div className="flex justify-between items-start mb-2">
              {review.title && (
                <h4 className="font-bold text-gray-900">{review.title}</h4>
              )}
              <div className="flex items-center">
                {renderStars(review.rating)}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs">
                {review.type === "hotel" ? "호텔" : 
                 review.type === "activity" ? "액티비티" : "여행지"}
              </Badge>
              {review.isVerified && (
                <Badge className="bg-green-100 text-green-800 text-xs">
                  인증된 리뷰
                </Badge>
              )}
            </div>
          </div>
        </div>
        
        {review.content && (
          <p className="text-gray-600 mb-4 leading-relaxed">{review.content}</p>
        )}
        
        {review.images && review.images.length > 0 && (
          <div className="grid grid-cols-3 gap-2 mb-4">
            {review.images.slice(0, 3).map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Review image ${index + 1}`}
                className="w-full h-20 object-cover rounded-lg"
              />
            ))}
          </div>
        )}
        
        <div className="text-sm text-gray-400">
          {formatDate(review.createdAt)}
        </div>
      </CardContent>
    </Card>
  );
}
