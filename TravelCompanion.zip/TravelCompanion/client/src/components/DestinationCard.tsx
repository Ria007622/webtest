import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import type { Destination } from "@shared/schema";

interface DestinationCardProps {
  destination: Destination;
  onClick?: () => void;
}

export default function DestinationCard({ destination, onClick }: DestinationCardProps) {
  return (
    <Card className="group cursor-pointer hover:shadow-xl transition-shadow" onClick={onClick}>
      <div className="relative overflow-hidden rounded-t-xl h-64">
        <img
          src={destination.imageUrl || "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"}
          alt={destination.nameKo}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        <div className="absolute bottom-4 left-4 text-white">
          <h3 className="text-xl font-bold">{destination.nameKo}</h3>
          <p className="text-sm opacity-90">{destination.countryKo}</p>
        </div>
        {destination.rating && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-white/90 text-gray-900">
              <Star className="h-3 w-3 mr-1 fill-yellow-400 text-yellow-400" />
              {destination.rating}
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        {destination.descriptionKo && (
          <p className="text-gray-600 text-sm line-clamp-2">{destination.descriptionKo}</p>
        )}
        {destination.reviewCount > 0 && (
          <p className="text-xs text-gray-500 mt-2">{destination.reviewCount}개의 리뷰</p>
        )}
      </CardContent>
    </Card>
  );
}
