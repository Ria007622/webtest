# YOLO Travel Planning Application

GitHub Pages로 호스팅되는 여행 계획 웹사이트입니다.

## 체험 계정
- 아이디: demo
- 비밀번호: demo123

## 로컬 실행
```bash
npm install
npm run dev
```

## 빌드
```bash
npm run build
```
